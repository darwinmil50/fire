/* =========================================================
   SAI - Sistema de Alerta de Incendios
   NASA FIRMS + Leaflet
   ========================================================= */

const CONFIG = {
  // Bounding boxes: west,south,east,north
  areas: {
    colombia: "-79.5,-4.5,-66.5,13.5",
    norte: "-82,-6,-60,15",
    sudamerica: "-85,-25,-35,15"
  },

  // Umbrales heurísticos de FRP (MW).
  // No representan "tamaño físico" del incendio.
  thresholds: {
    medium: 20,
    high: 50,
    critical: 100
  },

  // Si hay muchos puntos cercanos, elevamos la prioridad visual.
  clusterRadiusKm: 12,
  clusterCountCritical: 7
};

const state = {
  map: null,
  markers: [],
  key: localStorage.getItem("sai_firms_map_key") || "",
  fires: []
};

const $ = (id) => document.getElementById(id);

const areaSelect = $("areaSelect");
const daysRange = $("daysRange");
const sensorSelect = $("sensorSelect");
const mapKeyInput = $("mapKey");
const statusBox = $("status");
const loading = $("loading");

mapKeyInput.value = state.key;

function setStatus(message, type = "info") {
  statusBox.textContent = message;
  statusBox.className = `status ${type}`;
}

function setLoading(show) {
  loading.classList.toggle("hidden", !show);
}

function initMap() {
  state.map = L.map("map", { zoomControl: true }).setView([4.57, -74.29], 6);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>'
  }).addTo(state.map);

  L.control.scale({ imperial: false }).addTo(state.map);
}

function parseCSV(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (ch === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === "," && !inQuotes) {
      row.push(cell);
      cell = "";
    } else if ((ch === "\n" || ch === "\r") && !inQuotes) {
      if (ch === "\r" && next === "\n") i++;
      row.push(cell);
      if (row.some(v => v.trim() !== "")) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += ch;
    }
  }

  if (cell.length || row.length) {
    row.push(cell);
    if (row.some(v => v.trim() !== "")) rows.push(row);
  }

  if (!rows.length) return [];

  const headers = rows[0].map(h => h.trim());
  return rows.slice(1).map(values => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = (values[i] ?? "").trim());
    return obj;
  });
}

function normalizeFire(raw) {
  return {
    latitude: Number(raw.latitude),
    longitude: Number(raw.longitude),
    frp: Number(raw.frp) || 0,
    confidence: raw.confidence || "—",
    date: raw.acq_date || "—",
    time: raw.acq_time || "—",
    satellite: raw.satellite || "—",
    instrument: raw.instrument || "VIIRS",
    daynight: raw.daynight || "—"
  };
}

function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const p1 = lat1 * Math.PI / 180;
  const p2 = lat2 * Math.PI / 180;
  const dp = (lat2 - lat1) * Math.PI / 180;
  const dl = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(dp / 2) ** 2 +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;

  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function classifyFire(fire, allFires) {
  const t = CONFIG.thresholds;

  // Vecindad: ayuda a destacar zonas con varios puntos de calor próximos.
  let nearby = 0;
  for (const other of allFires) {
    if (other === fire) continue;
    if (distanceKm(fire.latitude, fire.longitude, other.latitude, other.longitude) <= CONFIG.clusterRadiusKm) {
      nearby++;
      if (nearby >= CONFIG.clusterCountCritical) break;
    }
  }

  if (fire.frp >= t.critical || nearby >= CONFIG.clusterCountCritical) return "critical";
  if (fire.frp >= t.high) return "high";
  if (fire.frp >= t.medium) return "medium";
  return "low";
}

function createFireIcon(level) {
  if (level === "critical") {
    return L.divIcon({
      className: "critical-div-icon",
      html: `
        <div class="fire-critical" aria-label="Incendio crítico">
          <div class="smoke s1"></div>
          <div class="smoke s2"></div>
          <div class="smoke s3"></div>
          <div class="smoke s4"></div>
          <div class="flame">🔥</div>
        </div>
      `,
      iconSize: [86, 112],
      iconAnchor: [43, 98],
      popupAnchor: [0, -90]
    });
  }

  return L.divIcon({
    className: "fire-div-icon",
    html: `
      <div class="fire-marker ${level}">
        <div class="flame">${level === "low" ? "•" : "🔥"}</div>
      </div>
    `,
    iconSize: [50, 50],
    iconAnchor: [25, 35],
    popupAnchor: [0, -32]
  });
}

function formatTime(value) {
  if (!value || value === "—") return "—";
  const s = String(value).padStart(4, "0");
  return `${s.slice(0, 2)}:${s.slice(2)} UTC`;
}

function popupHtml(fire, level) {
  const labels = {
    low: "BAJA",
    medium: "MODERADA",
    high: "ALTA",
    critical: "CRÍTICA"
  };

  const confidence = {
    l: "baja",
    n: "normal",
    h: "alta"
  }[String(fire.confidence).toLowerCase()] || fire.confidence;

  return `
    <div class="fire-popup">
      <h3>${level === "critical" ? "🔥 Incendio crítico" : "🔥 Detección de calor"}</h3>
      <p><strong>Nivel:</strong> <span class="level ${level === "critical" ? "critical" : ""}">${labels[level]}</span></p>
      <p><strong>FRP:</strong> ${fire.frp.toFixed(2)} MW</p>
      <p><strong>Coordenadas:</strong> ${fire.latitude.toFixed(5)}, ${fire.longitude.toFixed(5)}</p>
      <p><strong>Fecha:</strong> ${fire.date}</p>
      <p><strong>Hora:</strong> ${formatTime(fire.time)}</p>
      <p><strong>Confianza:</strong> ${confidence}</p>
      <p><strong>Satélite:</strong> ${fire.satellite}</p>
      <p><strong>Periodo:</strong> ${fire.daynight === "D" ? "Día" : fire.daynight === "N" ? "Noche" : fire.daynight}</p>
      ${level === "critical"
        ? `<p style="margin-top:9px;color:#ff8a78"><strong>⚠ Representación visual de alta prioridad: fuego + humo animado.</strong></p>`
        : ""}
    </div>
  `;
}

function clearMarkers() {
  for (const marker of state.markers) marker.remove();
  state.markers = [];
}

function renderFires(fires) {
  clearMarkers();

  let low = 0, medium = 0, high = 0, critical = 0;

  for (const fire of fires) {
    const level = classifyFire(fire, fires);

    if (level === "low") low++;
    if (level === "medium") medium++;
    if (level === "high") high++;
    if (level === "critical") critical++;

    const marker = L.marker(
      [fire.latitude, fire.longitude],
      { icon: createFireIcon(level), zIndexOffset: level === "critical" ? 1000 : 0 }
    );

    marker.bindPopup(popupHtml(fire, level));
    marker.addTo(state.map);
    state.markers.push(marker);
  }

  $("totalCount").textContent = fires.length;
  $("lowCount").textContent = low;
  $("mediumCount").textContent = medium;
  $("highCount").textContent = high;
  $("criticalCount").textContent = critical;
}

async function fetchFirms() {
  const key = state.key.trim();

  if (!key) {
    setStatus("Introduce tu MAP_KEY de NASA FIRMS para cargar los incendios.", "info");
    return;
  }

  const area = CONFIG.areas[areaSelect.value];
  const days = Number(daysRange.value);
  const sensor = sensorSelect.value;

  const url = `https://firms.modaps.eosdis.nasa.gov/api/area/csv/${encodeURIComponent(key)}/${sensor}/${area}/${days}`;

  setLoading(true);
  setStatus("Consultando datos recientes de NASA FIRMS…", "info");

  try {
    const response = await fetch(url, { cache: "no-store" });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`FIRMS respondió HTTP ${response.status}. ${body.slice(0, 180)}`);
    }

    const csv = await response.text();

    if (!csv || csv.trim().length < 20) {
      throw new Error("La respuesta de FIRMS llegó vacía.");
    }

    const rawRows = parseCSV(csv);
    const fires = rawRows
      .map(normalizeFire)
      .filter(f => Number.isFinite(f.latitude) && Number.isFinite(f.longitude));

    state.fires = fires;
    renderFires(fires);

    if (fires.length) {
      setStatus(
        `Se cargaron ${fires.length} detecciones de FIRMS. Las de mayor prioridad muestran fuego + humo.`,
        "success"
      );
    } else {
      setStatus("FIRMS no devolvió detecciones para la zona y periodo seleccionados.", "info");
    }
  } catch (error) {
    console.error(error);
    setStatus(
      `No se pudieron cargar los datos: ${error.message}. Revisa tu MAP_KEY y la conexión a internet.`,
      "error"
    );
  } finally {
    setLoading(false);
  }
}

$("saveKeyBtn").addEventListener("click", () => {
  const key = mapKeyInput.value.trim();

  if (!key) {
    setStatus("Pega primero tu MAP_KEY.", "error");
    return;
  }

  state.key = key;
  localStorage.setItem("sai_firms_map_key", key);
  setStatus("MAP_KEY guardada en este navegador. Cargando FIRMS…", "success");
  fetchFirms();
});

$("clearKeyBtn").addEventListener("click", () => {
  state.key = "";
  localStorage.removeItem("sai_firms_map_key");
  mapKeyInput.value = "";
  clearMarkers();
  state.fires = [];
  $("totalCount").textContent = "—";
  $("lowCount").textContent = "—";
  $("mediumCount").textContent = "—";
  $("highCount").textContent = "—";
  $("criticalCount").textContent = "—";
  setStatus("MAP_KEY eliminada de este navegador.", "info");
});

$("refreshBtn").addEventListener("click", fetchFirms);
areaSelect.addEventListener("change", fetchFirms);
daysRange.addEventListener("change", fetchFirms);
sensorSelect.addEventListener("change", fetchFirms);

$("locateBtn").addEventListener("click", () => {
  if (!navigator.geolocation) {
    setStatus("Tu navegador no permite geolocalización.", "error");
    return;
  }

  navigator.geolocation.getCurrentPosition(
    ({ coords }) => {
      state.map.setView([coords.latitude, coords.longitude], 10);
      L.circleMarker([coords.latitude, coords.longitude], {
        radius: 8,
        color: "#1473e6",
        fillColor: "#48a3ff",
        fillOpacity: .85
      }).addTo(state.map).bindPopup("Tu ubicación aproximada").openPopup();
    },
    () => setStatus("No fue posible obtener tu ubicación.", "error")
  );
});

initMap();

if (state.key) {
  setStatus("MAP_KEY encontrada en este navegador. Cargando datos…", "info");
  fetchFirms();
}
